TITLE:
HR2 - Free HTML5 Template

AUTHOR:
Hostingred SAS
Website: http://www.hostingred.com/

Demo Images:
https://pixabay.com/es/

Google Map
https://maps.google.com/

Contact Form
The contact form is processed by the file called 'contact-us.send.php'
located at the root folder, in that file you must change the line 6,
variable $to, changing its value by your company's email address.

Your server must allow php processing.
